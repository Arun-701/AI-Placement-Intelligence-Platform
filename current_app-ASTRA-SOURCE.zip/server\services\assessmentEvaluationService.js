const Assessment = require("../models/Assessment");
const AssessmentResult = require("../models/AssessmentResult");
const QuestionBank = require("../models/QuestionBank");

// Keep performance thresholds in one place.  A topic is only classified when
// the student has submitted at least one answer for that topic.
const PERFORMANCE_THRESHOLDS = Object.freeze({
    strong: 70,
    weak: 50
});

// These are import/UI placeholders, not learning topics.  Legacy questions
// carrying one of them remain scoreable, but are deliberately excluded from
// strengths/weaknesses until their QuestionBank topic is reviewed.
const NON_TOPIC_PLACEHOLDERS = new Set(["question paper", "general"]);

const getLearningTopic = (question) => {
    const topic = typeof question?.topic === "string" ? question.topic.trim() : "";
    return topic && !NON_TOPIC_PLACEHOLDERS.has(topic.toLowerCase()) ? topic : null;
};

const hasSubmittedAnswer = (selectedAnswer) =>
    typeof selectedAnswer === "string" && selectedAnswer.trim() !== "";

/**
 * Build topic performance from actual answer evidence.  totalQuestions is
 * retained for context, but skipped questions never enter the accuracy
 * denominator or the incorrect count.
 */
const buildTopicAnalysis = (questionAnswers) => {
    const topics = new Map();

    questionAnswers.forEach(({ question, selectedAnswer, isCorrect, marksObtained = 0 }) => {
        const topic = getLearningTopic(question);
        // A missing/placeholder topic is not evidence of a real skill. Do
        // not replace it with an assessment name or another invented label.
        if (!topic) return;
        const entry = topics.get(topic) || {
            topic,
            correctAnswers: 0,
            incorrectAnswers: 0,
            attemptedQuestions: 0,
            totalQuestions: 0,
            score: 0,
            totalMarks: 0,
            accuracy: null
        };

        entry.totalQuestions += 1;
        entry.totalMarks += Number(question.marks) || 0;
        entry.score += Number(marksObtained) || 0;

        if (hasSubmittedAnswer(selectedAnswer)) {
            entry.attemptedQuestions += 1;
            if (isCorrect) entry.correctAnswers += 1;
            else entry.incorrectAnswers += 1;
        }
        topics.set(topic, entry);
    });

    return Array.from(topics.values()).map((entry) => ({
        ...entry,
        accuracy: entry.attemptedQuestions === 0
            ? null
            : Number(((entry.correctAnswers / entry.attemptedQuestions) * 100).toFixed(2))
    }));
};

/**
 * Evaluate MCQ answer
 */
const evaluateMCQAnswer = (question, selectedAnswer) => {
    if (!question || question.questionType !== "MCQ") {
        return { isCorrect: false, marksObtained: 0 };
    }

    const isCorrect = selectedAnswer && selectedAnswer.trim().toLowerCase() === question.correctAnswer.trim().toLowerCase();
    const marksObtained = isCorrect ? question.marks : 0;

    return {
        isCorrect,
        marksObtained
    };
};

/**
 * Evaluate coding answer - Store code, placeholder for future compiler integration
 */
const evaluateCodingAnswer = (question, selectedAnswer) => {
    if (!question || question.questionType !== "Coding") {
        return { isCorrect: false, marksObtained: 0, status: "pending" };
    }

    // Store the code submission
    return {
        isCorrect: false, // Will be evaluated by compiler/manual review
        marksObtained: 0,
        status: "pending_evaluation",
        submittedCode: selectedAnswer,
        evaluatedAt: null
    };
};

/**
 * Evaluate subjective answer - Manual evaluation placeholder
 */
const evaluateSubjectiveAnswer = (question, selectedAnswer) => {
    if (!question || question.questionType !== "Subjective") {
        return { isCorrect: false, marksObtained: 0, status: "pending" };
    }

    // Placeholder for manual evaluation
    return {
        isCorrect: false,
        marksObtained: 0,
        status: "pending_manual_review",
        submittedAnswer: selectedAnswer,
        evaluatedAt: null
    };
};

/**
 * Compute total marks from the assessment questions
 */
const computeTotalMarks = (questions) => {
    return (questions || []).reduce((total, question) => {
        return total + (Number(question.marks) || 0);
    }, 0);
};

/**
 * Evaluate all answers and calculate results
 */
const evaluateAnswers = async (assessmentId, answers) => {
    const assessment = await Assessment.findById(assessmentId).populate("questions");

    if (!assessment) {
        throw new Error("Assessment not found");
    }

    const totalMarks = assessment.totalMarks > 0 ? assessment.totalMarks : computeTotalMarks(assessment.questions);

    const evaluatedAnswers = [];
    let totalScore = 0;
    let correctCount = 0;
    let wrongCount = 0;
    let skippedCount = 0;

    // Create a map for quick question lookup
    const questionMap = {};
    assessment.questions.forEach((q) => {
        questionMap[q._id.toString()] = q;
    });

    // Evaluate each answer
    for (const answer of answers) {
        const question = questionMap[answer.question.toString()];

        if (!question) {
            continue;
        }

        // Check if answer was skipped (empty or null)
        const isSkipped = !answer.selectedAnswer || answer.selectedAnswer.trim() === "";

        let evaluationResult;
        if (isSkipped) {
            skippedCount++;
            evaluationResult = {
                isCorrect: false,
                marksObtained: 0,
                status: "skipped"
            };
        } else {
            // Evaluate based on question type
            if (question.questionType === "MCQ") {
                evaluationResult = evaluateMCQAnswer(question, answer.selectedAnswer);
                if (evaluationResult.isCorrect) correctCount++;
                else wrongCount++;
            } else if (question.questionType === "Coding") {
                evaluationResult = evaluateCodingAnswer(question, answer.selectedAnswer);
                wrongCount++;
            } else if (question.questionType === "Subjective") {
                evaluationResult = evaluateSubjectiveAnswer(question, answer.selectedAnswer);
                wrongCount++;
            } else {
                // Aptitude, Technical, HR - treat as MCQ for now
                evaluationResult = evaluateMCQAnswer(question, answer.selectedAnswer);
                if (evaluationResult.isCorrect) correctCount++;
                else wrongCount++;
            }
        }

        totalScore += evaluationResult.marksObtained;

        evaluatedAnswers.push({
            question: answer.question,
            selectedAnswer: answer.selectedAnswer || "",
            isCorrect: evaluationResult.isCorrect,
            marksObtained: evaluationResult.marksObtained,
            ...evaluationResult
        });
    }

    const percentage = totalMarks > 0 ? Math.round((totalScore / totalMarks) * 100) : 0;

    return {
        score: totalScore,
        totalMarks,
        percentage: Math.min(100, percentage),
        answers: evaluatedAnswers,
        stats: {
            correctAnswers: correctCount,
            wrongAnswers: wrongCount,
            skippedAnswers: skippedCount,
            totalQuestions: assessment.questions.length
        },
        topicAnalysis: buildTopicAnalysis(evaluatedAnswers.map((answer) => ({
            question: questionMap[answer.question.toString()],
            ...answer
        })))
    };
};

/**
 * Identify strengths and weaknesses
 */
const identifyStrengthsAndWeaknesses = (evaluationResult, threshold = PERFORMANCE_THRESHOLDS.strong) => {
    const strengths = [];
    const weaknesses = [];

    evaluationResult.topicAnalysis.forEach((topic) => {
        // null accuracy means every question in this topic was skipped: no
        // performance evidence exists, so it must not become a weakness.
        if (topic.accuracy === null || topic.attemptedQuestions === 0) return;
        if (topic.accuracy >= threshold) {
            strengths.push(`Strong in ${topic.topic} (${topic.accuracy}% accuracy)`);
        } else if (topic.accuracy < PERFORMANCE_THRESHOLDS.weak) {
            weaknesses.push(`Very weak in ${topic.topic} (${topic.accuracy}% accuracy)`);
        } else {
            weaknesses.push(`Needs improvement in ${topic.topic} (${topic.accuracy}% accuracy)`);
        }
    });

    return { strengths, weaknesses };
};

/**
 * Generate recommendations based on performance
 */
const generateRecommendations = (evaluationResult, strengths, weaknesses) => {
    const recommendations = [];

    const attemptedQuestions = evaluationResult.topicAnalysis.reduce(
        (total, topic) => total + (topic.attemptedQuestions || 0), 0
    );

    if (attemptedQuestions === 0) {
        return ["Insufficient performance data. Attempt the assessment to establish your strengths and weaknesses."];
    }

    if (weaknesses.length > 0) {
        return evaluationResult.topicAnalysis
            .filter((topic) => topic.attemptedQuestions > 0 && topic.accuracy < PERFORMANCE_THRESHOLDS.strong)
            .map((topic) => `Practice and review ${topic.topic} concepts (${topic.accuracy}% accuracy).`);
    }

    const { percentage } = evaluationResult;

    if (percentage >= 80) {
        recommendations.push("Excellent performance! Keep practicing to maintain this level");
        recommendations.push("Try harder difficulty questions to further improve");
    } else {
        recommendations.push("Keep practicing the attempted topics to build consistency");
    }

    return recommendations;
};

/**
 * Create assessment result with evaluation
 */
const createAssessmentResult = async (studentId, assessmentId, answers, timeTaken = 0) => {
    // Evaluate answers
    const evaluationResult = await evaluateAnswers(assessmentId, answers);

    // Identify strengths and weaknesses
    const { strengths, weaknesses } = identifyStrengthsAndWeaknesses(evaluationResult);

    // Generate recommendations
    const recommendations = generateRecommendations(evaluationResult, strengths, weaknesses);

    // Create result document
    const result = new AssessmentResult({
        student: studentId,
        assessment: assessmentId,
        score: evaluationResult.score,
        totalMarks: evaluationResult.totalMarks,
        percentage: evaluationResult.percentage,
        answers: evaluationResult.answers,
        strengths,
        weaknesses,
        recommendations,
        topicAnalysis: evaluationResult.topicAnalysis,
        submittedAt: new Date(),
        completed: true
    });

    await result.save();

    return result;
};

/**
 * Get result summary
 */
const getResultSummary = async (resultId) => {
    const result = await AssessmentResult.findById(resultId)
        .populate("student", "name email studentId department")
        .populate("assessment", "title totalMarks duration assessmentType")
        .lean();

    if (!result) {
        return null;
    }

    return {
        _id: result._id,
        student: result.student,
        assessment: result.assessment,
        score: result.score,
        totalMarks: result.totalMarks,
        percentage: result.percentage,
        submittedAt: result.submittedAt,
        completed: result.completed,
        stats: {
            correctAnswers: result.answers.filter((a) => a.isCorrect).length,
            wrongAnswers: result.answers.filter((a) => !a.isCorrect && a.selectedAnswer).length,
            skippedAnswers: result.answers.filter((a) => !a.selectedAnswer).length,
            totalQuestions: result.answers.length
        },
        strengths: result.strengths,
        weaknesses: result.weaknesses,
        recommendations: result.recommendations,
        topicAnalysis: result.topicAnalysis
    };
};

module.exports = {
    evaluateMCQAnswer,
    evaluateCodingAnswer,
    evaluateSubjectiveAnswer,
    evaluateAnswers,
    identifyStrengthsAndWeaknesses,
    generateRecommendations,
    createAssessmentResult,
    getResultSummary,
    computeTotalMarks,
    buildTopicAnalysis,
    PERFORMANCE_THRESHOLDS,
    getLearningTopic
};
