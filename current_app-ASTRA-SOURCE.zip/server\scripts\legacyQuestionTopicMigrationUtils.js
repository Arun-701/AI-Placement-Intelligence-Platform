const fs = require("fs");
const path = require("path");

const mappingPath = path.resolve(__dirname, "../data/legacyQuestionTopicMapping.json");
const normalizeQuestionText = (value) => String(value || "")
  .replace(/\s+/g, " ")
  .trim()
  .toLocaleLowerCase();

const loadMigrationMapping = () => {
  const config = JSON.parse(fs.readFileSync(mappingPath, "utf8"));
  const mapping = new Map();
  for (const entry of config.mappings || []) {
    const key = normalizeQuestionText(entry.question);
    if (!key || !entry.topic || mapping.has(key)) throw new Error("Invalid or duplicate migration mapping entry");
    mapping.set(key, entry.topic);
  }
  if (mapping.size !== config.expectedUniqueQuestionCount) throw new Error("Mapping count does not match expectedUniqueQuestionCount");
  return { config, mapping };
};

const buildAudit = (questions) => {
  const { config, mapping } = loadMigrationMapping();
  const groups = new Map();
  for (const question of questions) {
    const key = normalizeQuestionText(question.question);
    const group = groups.get(key) || { question: question.question, ids: [], topics: new Set(), proposedTopic: mapping.get(key) || null };
    group.ids.push(String(question._id));
    group.topics.add(question.topic);
    groups.set(key, group);
  }
  const unmapped = [...groups.values()].filter((group) => !group.proposedTopic);
  const missingFromDatabase = [...mapping.keys()].filter((key) => !groups.has(key));
  const inconsistent = [...groups.values()].filter((group) => group.topics.size !== 1 || !group.topics.has("Question Paper"));
  const valid = questions.length === config.expectedRecordCount
    && groups.size === config.expectedUniqueQuestionCount
    && unmapped.length === 0
    && missingFromDatabase.length === 0
    && inconsistent.length === 0;
  return { valid, config, groups: [...groups.values()], unmapped, missingFromDatabase, inconsistent };
};

module.exports = { normalizeQuestionText, loadMigrationMapping, buildAudit };
