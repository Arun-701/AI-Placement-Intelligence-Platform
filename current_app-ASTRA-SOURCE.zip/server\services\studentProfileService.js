const Student = require("../models/Student");
const Roadmap = require("../models/Roadmap");
const AssessmentResult = require("../models/AssessmentResult");
const { getMissingProfileFields } = require("../validators/studentProfileValidator");

// Only the visible/profile onboarding fields are required for completion
const PROFILE_FIELDS = [
  "fullName",
  "phone",
  "college",
  "section",
  "github",
  "linkedin",
  "skills",
  "cgpa"
];

const calculateProfileCompletion = (student) => {
  const missingFields = PROFILE_FIELDS.filter((field) => {
    const value = student[field];
    if (Array.isArray(value)) return value.length === 0;
    if (typeof value === 'string') return value.trim() === '';
    return value === null || value === undefined;
  });
  const completedFields = PROFILE_FIELDS.length - missingFields.length;
  const percentage = PROFILE_FIELDS.length === 0 ? 100 : Math.round((completedFields / PROFILE_FIELDS.length) * 100);

  return {
    percentage,
    missingFields,
    profileCompleted: percentage === 100
  };
};

const getStudentProfile = async (studentId) => {
  const student = await Student.findById(studentId)
    .select("fullName email phone gender dateOfBirth department year section cgpa college skills interests linkedin github leetcode hackerrank codechef codeforces resume codingProfile isVerified isActive assessmentsCompleted profileCompleted initialAssessmentCompleted")
    .lean();
  if (!student) {
    throw new Error("Student not found");
  }

  const completion = calculateProfileCompletion(student);
  return {
    student: {
      fullName: student.fullName || "",
      email: student.email,
      phone: student.phone || "",
      gender: student.gender || "",
      dateOfBirth: student.dateOfBirth || null,
      department: student.department || "",
      year: student.year || null,
      cgpa: student.cgpa === undefined ? null : student.cgpa,
      college: student.college || "",
      skills: student.skills || [],
      interests: student.interests || [],
      linkedin: student.linkedin || "",
      github: student.github || "",
      leetcode: student.leetcode || "",
      hackerrank: student.hackerrank || "",
      codechef: student.codechef || "",
      codeforces: student.codeforces || "",
      codingProfile: student.codingProfile || { score: 0 },
      resume: student.resume || "",
      emailVerified: student.isVerified,
      accountActive: student.isActive,
      assessmentsCompleted: student.assessmentsCompleted || 0,
      initialAssessmentCompleted: student.initialAssessmentCompleted || false,
      profileCompleted: completion.profileCompleted,
      profileCompletion: completion.percentage
    }
  };
};

const getStudentDashboard = async (studentId) => {
  const profile = await getStudentProfile(studentId);
  const [roadmap, assessmentsCompleted] = await Promise.all([
    Roadmap.findOne({ student: studentId }).lean(),
    AssessmentResult.countDocuments({ student: studentId, completed: true })
  ]);
  const totalProblemsSolved = profile.student.codingProfile?.totalProblemsSolved || 0;

  return {
   profileCompletion: profile.student.profileCompletion,
    resumeUploaded: Boolean(profile.student.resume),
    emailVerified: profile.student.emailVerified,
    codingProfilesConnected: Boolean(profile.student.github || profile.student.leetcode || profile.student.codechef || profile.student.hackerrank || profile.student.codeforces),
    assessmentsCompleted,
    codingScore: totalProblemsSolved,
    kpiCards: {
      codingScore: totalProblemsSolved,
      assessmentsCompleted
    },
    roadmapAvailable: Boolean(roadmap)
  };
};

const updateStudentProfile = async (studentId, updates) => {
  const student = await Student.findById(studentId);
  if (!student) {
    throw new Error("Student not found");
  }

  PROFILE_FIELDS.forEach((field) => {
    if (Object.prototype.hasOwnProperty.call(updates, field)) {
      student[field] = updates[field];
    }
  });

  const completion = calculateProfileCompletion(student);
  student.profileCompleted = completion.profileCompleted;
  await student.save();

  return {
    student,
    profileCompletion: completion.percentage,
    missingFields: completion.missingFields
  };
};

const getProfileCompletionStatus = async (studentId) => {
  const student = await Student.findById(studentId).lean();
  if (!student) {
    throw new Error("Student not found");
  }

  return calculateProfileCompletion(student);
};

module.exports = {
  PROFILE_FIELDS,
  calculateProfileCompletion,
  getStudentProfile,
  getStudentDashboard,
  updateStudentProfile,
  getProfileCompletionStatus
};
