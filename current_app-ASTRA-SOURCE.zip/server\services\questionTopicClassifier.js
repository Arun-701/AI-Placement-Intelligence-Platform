const roadmaps = require("../data/roadmaps.json");
const QuestionBank = require("../models/QuestionBank");

const ROADMAP_TOPICS = new Set(Object.values(roadmaps).flatMap((roadmap) => [roadmap.displayName, ...(roadmap.topics || []).map((topic) => topic.title)]));
const REQUIRED_TOPICS = new Set(["Machine Learning", "Computer Architecture", "Software Engineering", "SQL Query Clauses", "MongoDB", "SELECT", "DBMS"]);

// Multi-signal, deterministic rules. Generic words such as "algorithm" and
// "data" are intentionally absent to avoid unsupported classifications.
const TOPIC_SIGNALS = {
  "Linked Lists, Stacks, Queues": [["fifo", 5], ["lifo", 5], ["queue", 4], ["stack", 4], ["enqueue", 5], ["dequeue", 5], ["linked list", 4], ["earliest inserted", 5]],
  "Sorting & Searching": [["binary search", 6], ["linear search", 5], ["merge sort", 6], ["quick sort", 6], ["bubble sort", 6], ["selection sort", 6], ["sorting algorithm", 6], ["sorting", 3], ["sorted array", 4], ["search interval", 4]],
  HTML: [["html", 6], ["web page structure", 5], ["structure the content", 5], ["markup", 4], ["anchor tag", 5], ["hyperlink", 4], ["semantic html", 6]],
  SELECT: [["select statement", 6], ["select command", 6], ["retrieve data", 5], ["retrieves data", 5], ["fetch records", 5], ["fetches records", 5], ["fetch rows", 5], ["fetches rows", 5], ["retrieving rows", 5], ["selecting columns", 5], ["distinct", 4]],
  "SQL Query Clauses": [["where clause", 6], ["having clause", 6], ["group by", 5], ["order by", 5], ["sql clause", 5], ["filter rows", 4], ["filtering rows", 4], ["before grouping", 5]],
  "Machine Learning": [["supervised learning", 6], ["unsupervised learning", 6], ["machine learning", 5], ["classification", 4], ["regression", 4], ["clustering", 5], ["k means", 6], ["pca", 5], ["labeled data", 5], ["unlabeled data", 5], ["labeled outputs", 5], ["unlabeled outputs", 5]],
  "HTTP & REST": [["https", 6], ["http", 4], ["status code", 5], ["404", 5], ["500", 5], ["rest api", 5], ["http request", 5], ["http response", 5], ["encrypted http", 6], ["securely transfer web pages", 6]],
  "Computer Architecture": [["cpu", 6], ["ram", 6], ["processor", 5], ["cache", 4], ["registers", 4], ["instruction execution", 5], ["executes instructions", 6], ["computer instructions", 5], ["memory hierarchy", 5]],
  DBMS: [["normalization", 5], ["normal form", 6], ["1nf", 5], ["2nf", 5], ["3nf", 5], ["bcnf", 5], ["partial dependency", 6], ["transitive dependency", 6], ["relational database", 4]],
  MongoDB: [["mongodb", 11], ["document database", 5], ["bson", 6], ["27017", 11]],
  Databases: [["nosql database", 6], ["nosql", 4], ["database schema", 4]],
  "OOP in Java": [["java inheritance", 6], ["inherit a class", 6], ["inherits a class", 6], ["extends", 5], ["implements", 5], ["polymorphism", 4], ["encapsulation", 4], ["abstraction", 4], ["java class", 4]],
  "Python Fundamentals": [["python", 4], ["mutable", 4], ["immutable", 4], ["python data type", 6], ["python object", 5], ["dictionary", 3], ["tuple", 3], ["python list", 4]],
  "Trees & Graphs": [["dijkstra", 7], ["shortest path", 6], ["weighted graph", 6], ["non negative edge", 6], ["graph", 3], ["vertex", 4], ["edge", 4], ["bfs", 5], ["dfs", 5], ["tree traversal", 5]],
  "Hooks & State": [["react hook", 6], ["react", 3], ["usestate", 7], ["useeffect", 6], ["usememo", 6], ["useref", 6], ["component state", 6]],
  "Software Engineering": [["sdlc", 7], ["requirements analysis", 7], ["system requirements", 6], ["design phase", 4], ["deployment", 3], ["maintenance", 3], ["software development lifecycle", 7], ["system should do", 6]],
  "Quantitative Aptitude Basics": [["percentage", 7], ["percent", 6], ["% of", 6], ["percentage increase", 7], ["percentage decrease", 7], ["ratio", 7], ["proportion", 6], ["average", 6], ["mean value", 5], ["number system", 6], ["train travels", 7], ["speed", 5], ["distance", 4], ["km in", 5], ["complete a job", 7], ["complete a work", 7], ["complete a task", 7], ["days and", 4], ["probability", 8], ["coin is tossed", 7], ["coins are tossed", 7], ["outcomes", 5], ["profit", 6], ["loss", 6], ["discount", 5], ["simple interest", 8], ["compound interest", 8]],
  "Logical Reasoning": [["next number in the series", 8], ["next letter in the series", 8], ["number series", 7], ["letter series", 7], ["sitting around", 7], ["circular table", 8], ["seating arrangement", 8], ["seated in a row", 7], ["pointing to a person", 8], ["blood relation", 8], ["brother of", 5], ["sister of", 5], ["odd one out", 7], ["syllogism", 8], ["coding decoding", 8], ["coded as", 6], ["direction", 5]],
  "Verbal Ability": [["opposite in meaning", 8], ["similar in meaning", 7], ["synonym", 8], ["antonym", 8], ["vocabulary", 7], ["grammatically correct", 8], ["correct grammar", 7], ["grammar", 6], ["reading comprehension", 8], ["passage", 4]]
};

const normalizeQuestionText = (value) => String(value || "").toLowerCase().replace(/(\d)\s*[×x]\s*(\d)/g, "$1 multiply $2").replace(/[÷]/g, " divided by ").replace(/%/g, " percent ").replace(/[²]/g, " squared ").replace(/\^\s*2\b/g, " squared ").replace(/[^a-z0-9+#.]+/g, " ").replace(/\bk[-\s]?means\b/g, "k means").replace(/\bnon[-\s]?negative\b/g, "non negative").replace(/\s+/g, " ").trim();

const getApprovedTopics = async () => {
  const storedTopics = await QuestionBank.distinct("topic", { topic: { $nin: ["Question Paper", "General", ""] } });
  return [...new Set([...ROADMAP_TOPICS, ...REQUIRED_TOPICS, ...storedTopics])].sort();
};

const classifyQuestionTopic = (question, approvedTopics) => {
  const text = normalizeQuestionText(question);
  const scores = Object.entries(TOPIC_SIGNALS).map(([topic, signals]) => ({ topic, score: signals.reduce((total, [signal, weight]) => total + (text.includes(signal) ? weight : 0), 0) })).filter((entry) => entry.score > 0 && approvedTopics.includes(entry.topic)).sort((a, b) => b.score - a.score);
  const best = scores[0]; const runnerUp = scores[1];
  if (!best || best.score < 4) return { topic: "", topicSource: "unclassified", topicConfidence: "low" };
  return { topic: best.topic, topicSource: "auto", topicConfidence: best.score >= 6 && (!runnerUp || best.score - runnerUp.score >= 2) ? "high" : "medium" };
};

module.exports = { getApprovedTopics, classifyQuestionTopic, normalizeQuestionText };
