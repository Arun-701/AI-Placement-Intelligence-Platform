require("dotenv").config({ path: require("path").resolve(__dirname, "../.env") });
const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
const QuestionBank = require("../models/QuestionBank");
const { buildAudit } = require("./legacyQuestionTopicMigrationUtils");

const apply = process.argv.includes("--apply");
const migrationId = `issue4-legacy-question-topics-${new Date().toISOString().replace(/[:.]/g, "-")}`;

const run = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  const questions = await QuestionBank.find({ topic: "Question Paper" }).select("_id question topic").lean();
  const audit = buildAudit(questions);
  if (!audit.valid) throw new Error(`Pre-migration audit failed: ${questions.length} records, ${audit.groups.length} unique texts`);

  const planned = audit.groups.flatMap((group) => group.ids.map((id) => ({ id, question: group.question, oldTopic: "Question Paper", newTopic: group.proposedTopic })));
  console.log(JSON.stringify({ migrationId, mode: apply ? "APPLY" : "DRY_RUN", plannedRecords: planned.length, plannedTopics: [...new Set(planned.map((item) => item.newTopic))], sample: planned.slice(0, 5) }, null, 2));
  if (!apply) return;

  const backupDirectory = path.resolve(__dirname, "../data/migration-backups");
  fs.mkdirSync(backupDirectory, { recursive: true });
  const snapshotPath = path.join(backupDirectory, `${migrationId}.questionbank.json`);
  fs.writeFileSync(snapshotPath, JSON.stringify({ migrationId, createdAt: new Date().toISOString(), records: planned }, null, 2));

  const operations = planned.map((item) => ({
    updateOne: {
      filter: { _id: new mongoose.Types.ObjectId(item.id), topic: "Question Paper" },
      update: { $set: { topic: item.newTopic } }
    }
  }));
  const write = await QuestionBank.bulkWrite(operations, { ordered: true });
  if (write.matchedCount !== planned.length || write.modifiedCount !== planned.length) {
    throw new Error(`Migration write mismatch: matched ${write.matchedCount}, modified ${write.modifiedCount}, expected ${planned.length}. Snapshot: ${snapshotPath}`);
  }
  const remaining = await QuestionBank.countDocuments({ topic: "Question Paper", _id: { $in: planned.map((item) => item.id) } });
  if (remaining !== 0) throw new Error(`Post-migration verification failed: ${remaining} targeted records still have Question Paper`);
  const samples = await QuestionBank.find({ _id: { $in: planned.map((item) => item.id) } }).select("question topic").lean();
  const incorrect = samples.filter((question) => planned.find((item) => item.id === String(question._id))?.newTopic !== question.topic);
  if (incorrect.length) throw new Error(`Post-migration topic verification failed for ${incorrect.length} records`);
  console.log(JSON.stringify({ migrationId, updatedRecords: write.modifiedCount, remainingTargetedQuestionPaperRecords: remaining, snapshotPath, status: "PASS" }, null, 2));
};

run().catch((error) => { console.error("Legacy question topic migration failed:", error.message); process.exitCode = 1; })
  .finally(async () => mongoose.disconnect());
