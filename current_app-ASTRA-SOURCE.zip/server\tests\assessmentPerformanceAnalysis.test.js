const assert = require("assert");
const {
    buildTopicAnalysis,
    identifyStrengthsAndWeaknesses,
    generateRecommendations
} = require("../services/assessmentEvaluationService");

const entry = (topic, selectedAnswer, isCorrect, subtopic) => ({
    question: { topic, ...(subtopic ? { subtopic } : {}), marks: 1 },
    selectedAnswer,
    isCorrect,
    marksObtained: isCorrect ? 1 : 0
});

const analyse = (answers) => {
    const topicAnalysis = buildTopicAnalysis(answers);
    const input = { topicAnalysis, percentage: 0 };
    const { strengths, weaknesses } = identifyStrengthsAndWeaknesses(input);
    return { topicAnalysis, strengths, weaknesses, recommendations: generateRecommendations(input, strengths, weaknesses) };
};

// Zero attempted/all skipped: no 0%-accuracy weakness or generic poor-result advice.
let result = analyse([entry("SQL", "", false), entry("SQL", "", false)]);
assert.strictEqual(result.topicAnalysis[0].attemptedQuestions, 0);
assert.strictEqual(result.topicAnalysis[0].accuracy, null);
assert.deepStrictEqual(result.weaknesses, []);
assert.match(result.recommendations[0], /Insufficient performance data/);

// One correct and one incorrect are both evidence; only the latter is weak.
result = analyse([entry("SELECT", "A", true), entry("JOIN", "B", false)]);
assert.match(result.strengths[0], /SELECT/);
assert.match(result.weaknesses[0], /JOIN/);
assert.match(result.recommendations[0], /JOIN/);

// All-correct and all-incorrect assessments remain distinguishable.
result = analyse([entry("Arrays", "A", true), entry("Arrays", "B", true)]);
assert.strictEqual(result.weaknesses.length, 0);
result = analyse([entry("Arrays", "A", false), entry("Arrays", "B", false)]);
assert.match(result.weaknesses[0], /0% accuracy/);

// Mixed evidence: skips do not lower topic accuracy (SELECT is 100%, JOIN is 0%).
result = analyse([entry("SELECT", "A", true), entry("SELECT", "", false), entry("JOIN", "B", false), entry("JOIN", "", false)]);
assert.strictEqual(result.topicAnalysis.find((item) => item.topic === "SELECT").accuracy, 100);
assert.strictEqual(result.topicAnalysis.find((item) => item.topic === "JOIN").accuracy, 0);

// Multiple topics stay separate. Questions with no usable topic metadata are
// safely excluded rather than being called an assessment/category name.
result = analyse([entry("WHERE", "A", true), entry("Subqueries", "B", false), entry(undefined, "", false)]);
assert.match(result.strengths[0], /WHERE/);
assert.match(result.weaknesses[0], /Subqueries/);
assert.strictEqual(result.topicAnalysis.find((item) => item.topic === "General"), undefined);

// Legacy import placeholders must never appear as a learning weakness.
result = analyse([entry("Question Paper", "A", false), entry("Question Paper", "", false)]);
assert.deepStrictEqual(result.topicAnalysis, []);
assert.deepStrictEqual(result.weaknesses, []);
assert.match(result.recommendations[0], /Insufficient performance data/);

console.log("assessment performance analysis tests passed");
