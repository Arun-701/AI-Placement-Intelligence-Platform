require("dotenv").config({ path: require("path").resolve(__dirname, "../.env") });
const mongoose = require("mongoose");
const QuestionBank = require("../models/QuestionBank");
const { buildAudit } = require("./legacyQuestionTopicMigrationUtils");

const run = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  const questions = await QuestionBank.find({ topic: "Question Paper" }).select("_id question topic").lean();
  const audit = buildAudit(questions);
  console.log(JSON.stringify({
    migrationId: audit.config.version,
    targetedRecords: questions.length,
    uniqueQuestionTexts: audit.groups.length,
    duplicateCount: questions.length - audit.groups.length,
    groups: audit.groups.map(({ question, ids, proposedTopic }) => ({ question, records: ids.length, currentTopic: "Question Paper", proposedTopic })),
    unmapped: audit.unmapped.map((group) => group.question),
    missingFromDatabase: audit.missingFromDatabase,
    inconsistencies: audit.inconsistent.map((group) => group.question),
    status: audit.valid ? "PASS" : "FAIL"
  }, null, 2));
  if (!audit.valid) process.exitCode = 1;
};

run().catch((error) => { console.error("Legacy topic audit failed:", error.message); process.exitCode = 1; })
  .finally(async () => mongoose.disconnect());
