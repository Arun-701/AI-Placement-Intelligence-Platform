require("dotenv").config({ path: require("path").resolve(__dirname, "../.env") });
const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
const AssessmentResult = require("../models/AssessmentResult");
const QuestionBank = require("../models/QuestionBank");
const { buildTopicAnalysis, identifyStrengthsAndWeaknesses, generateRecommendations } = require("../services/assessmentEvaluationService");

const apply = process.argv.includes("--apply");
const migrationId = `issue4-regenerate-topic-analysis-${new Date().toISOString().replace(/[:.]/g, "-")}`;

const loadLatestQuestionBankSnapshot = () => {
  const backupDirectory = path.resolve(__dirname, "../data/migration-backups");
  const snapshotName = fs.readdirSync(backupDirectory)
    .filter((name) => /^issue4-legacy-question-topics-.*\.questionbank\.json$/.test(name))
    .sort()
    .at(-1);
  if (!snapshotName) throw new Error("No completed QuestionBank migration snapshot was found");
  const snapshot = JSON.parse(fs.readFileSync(path.join(backupDirectory, snapshotName), "utf8"));
  const ids = new Set((snapshot.records || []).map((record) => String(record.id)));
  if (ids.size !== 380) throw new Error(`QuestionBank migration snapshot contains ${ids.size} IDs, expected 380`);
  return { snapshotPath: path.join(backupDirectory, snapshotName), ids };
};

const run = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  const { ids: migratedIds, snapshotPath: questionBankSnapshotPath } = loadLatestQuestionBankSnapshot();
  const migratedQuestions = await QuestionBank.find({ _id: { $in: [...migratedIds] } }).select("_id topic").lean();
  if (migratedQuestions.length !== migratedIds.size) throw new Error("One or more migrated QuestionBank records no longer exist");
  const unresolved = migratedQuestions.filter((question) => question.topic === "Question Paper");
  if (unresolved.length) throw new Error(`QuestionBank migration has not completed; ${unresolved.length} mapped questions still use Question Paper`);

  const results = await AssessmentResult.find({ "answers.question": { $in: [...migratedIds] } }).populate({ path: "answers.question", select: "topic marks" });
  const plans = results.map((result) => {
    const topicAnalysis = buildTopicAnalysis(result.answers.filter((answer) => answer.question).map((answer) => ({
      question: answer.question,
      selectedAnswer: answer.selectedAnswer,
      isCorrect: answer.isCorrect,
      marksObtained: answer.marksObtained
    })));
    const input = { percentage: result.percentage, topicAnalysis };
    const { strengths, weaknesses } = identifyStrengthsAndWeaknesses(input);
    const recommendations = generateRecommendations(input, strengths, weaknesses);
    return { result, topicAnalysis, strengths, weaknesses, recommendations };
  });

  console.log(JSON.stringify({ migrationId, mode: apply ? "APPLY" : "DRY_RUN", questionBankSnapshotPath, affectedResults: plans.map((plan) => ({
    resultId: String(plan.result._id), oldTopicAnalysis: plan.result.topicAnalysis, newTopicAnalysis: plan.topicAnalysis,
    oldStrengths: plan.result.strengths, newStrengths: plan.strengths, oldWeaknesses: plan.result.weaknesses,
    newWeaknesses: plan.weaknesses, oldRecommendations: plan.result.recommendations, newRecommendations: plan.recommendations
  })) }, null, 2));
  if (!apply) return;

  const backupDirectory = path.resolve(__dirname, "../data/migration-backups");
  fs.mkdirSync(backupDirectory, { recursive: true });
  const snapshot = plans.map((plan) => ({ resultId: String(plan.result._id), topicAnalysis: plan.result.topicAnalysis, strengths: plan.result.strengths, weaknesses: plan.result.weaknesses, recommendations: plan.result.recommendations }));
  const snapshotPath = path.join(backupDirectory, `${migrationId}.assessment-results.json`);
  fs.writeFileSync(snapshotPath, JSON.stringify({ migrationId, createdAt: new Date().toISOString(), records: snapshot }, null, 2));
  for (const plan of plans) {
    plan.result.topicAnalysis = plan.topicAnalysis;
    plan.result.strengths = plan.strengths;
    plan.result.weaknesses = plan.weaknesses;
    plan.result.recommendations = plan.recommendations;
    await plan.result.save();
  }
  console.log(JSON.stringify({ migrationId, regeneratedResults: plans.length, snapshotPath, status: "PASS" }, null, 2));
};

run().catch((error) => { console.error("Historical topic analysis regeneration failed:", error.message); process.exitCode = 1; })
  .finally(async () => mongoose.disconnect());
