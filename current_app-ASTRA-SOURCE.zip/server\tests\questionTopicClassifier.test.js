const assert = require("assert");
const { classifyQuestionTopic } = require("../services/questionTopicClassifier");

const approvedTopics = [
  "Linked Lists, Stacks, Queues", "Sorting & Searching", "HTML", "SELECT", "Machine Learning", "HTTP & REST", "Computer Architecture", "DBMS", "OOP in Java", "MongoDB", "SQL Query Clauses", "Python Fundamentals", "Trees & Graphs", "Hooks & State", "Software Engineering", "Databases", "Quantitative Aptitude Basics", "Logical Reasoning", "Verbal Ability"
];
const cases = [
  ["Which data structure follows the FIFO principle?", "Linked Lists, Stacks, Queues"], ["What is the time complexity of binary search on a sorted array?", "Sorting & Searching"], ["Which language structures a web page? HTML", "HTML"], ["Which SQL command retrieves data?", "SELECT"], ["Which is a supervised learning algorithm?", "Machine Learning"], ["Which protocol provides encrypted HTTP communication?", "HTTP & REST"], ["What does RAM stand for?", "Computer Architecture"], ["Which normal form removes partial dependency?", "DBMS"], ["Which Java keyword inherits a class?", "OOP in Java"], ["Which is a NoSQL database MongoDB?", "MongoDB"], ["Which SQL WHERE clause filters rows before grouping?", "SQL Query Clauses"], ["Which Python object can be modified after creation?", "Python Fundamentals"], ["Dijkstra finds the shortest path in a weighted graph", "Trees & Graphs"], ["What React hook stores component state?", "Hooks & State"], ["Which SDLC phase identifies system requirements?", "Software Engineering"]
];
cases.forEach(([question, topic]) => assert.strictEqual(classifyQuestionTopic(question, approvedTopics).topic, topic, question));
const aptitudeCases = [
  ["What is 25% of 240?", "Quantitative Aptitude Basics"],
  ["A train travels 120 km in 2 hours. What is its speed?", "Quantitative Aptitude Basics"],
  ["A can complete a job in 10 days and B can complete it in 15 days.", "Quantitative Aptitude Basics"],
  ["The ratio of boys to girls is 3:2.", "Quantitative Aptitude Basics"],
  ["What is the probability of getting a head when a coin is tossed?", "Quantitative Aptitude Basics"],
  ["What is the next number in the series 2, 4, 8, 16?", "Logical Reasoning"],
  ["Five people are sitting around a circular table.", "Logical Reasoning"],
  ["Pointing to a person, A says he is the brother of B.", "Logical Reasoning"],
  ["Choose the word opposite in meaning to happy.", "Verbal Ability"],
  ["Choose the grammatically correct sentence.", "Verbal Ability"]
];
aptitudeCases.forEach(([question, topic]) => assert.strictEqual(classifyQuestionTopic(question, approvedTopics).topic, topic, question));
const paraphraseCases = [
  ["What structure removes the earliest inserted element first?", "Linked Lists, Stacks, Queues"],
  ["Which search method repeatedly divides the search interval?", "Sorting & Searching"],
  ["Which SQL statement fetches rows from a table?", "SELECT"],
  ["Which Python data structure can be modified after creation?", "Python Fundamentals"],
  ["Which React hook is used to store component state?", "Hooks & State"],
  ["Which protocol encrypts HTTP communication?", "HTTP & REST"],
  ["Which sorting algorithm has an average-case time complexity of O(n log n)?", "Sorting & Searching"]
];
paraphraseCases.forEach(([question, topic]) => assert.strictEqual(classifyQuestionTopic(question, approvedTopics).topic, topic, question));
assert.strictEqual(classifyQuestionTopic("What is an algorithm?", approvedTopics).topic, "");
console.log("question topic classifier tests passed");
